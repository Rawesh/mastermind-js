//6 kleuren
var z = ["orange", "blue", "yellow", "green", "purple", "black"];

//lege array om kleurcode in te stoppen velden
var input = [];
//lege array plaatsen van de kleuren velden
var inputcolor = []; 

var teller = 0;

//radom kleur in de vakken programmeren
var field = document.getElementById("first").childNodes;

//kleuren
var orange 	= document.getElementById("orange");
var blue 	= document.getElementById("blue");
var yellow 	= document.getElementById("yellow");
var green 	= document.getElementById("green");
var purple 	= document.getElementById("purple");
var black 	= document.getElementById("black");

orange.style.display = "none";
blue.style.display = "none";
yellow.style.display = "none";
green.style.display = "none";
purple.style.display = "none";
black.style.display = "none";


//willekeurige kleuren uit array z halen en in de console log tonen.
input[0] = z [Math.floor((Math.random() * 6 ))] ;
input[1] = z [Math.floor((Math.random() * 6 ))] ;
input[2] = z [Math.floor((Math.random() * 6 ))] ;
input[3] = z [Math.floor((Math.random() * 6 ))] ;
console.log(input)

//start het spel
function newgame() {
	//make the colors visible
	orange.style.display = "block";
	blue.style.display = "block";
	yellow.style.display = "block";
	green.style.display = "block";
	purple.style.display = "block";
	black.style.display = "block";

    //dit zijn de velden waar de kleuren in komen te staan
    field[1].style.backgroundColor = input[0];
    field[3].style.backgroundColor = input[1];
    field[5].style.backgroundColor = input[2];
    field[7].style.backgroundColor = input[3];

  }

function setcolor(color,setid){
	//velden plaatsen met eigen id
	var id_row1 = document.getElementById('row1');
	var fldset  = document.createElement("fieldset");
	var colorchoise=document.getElementById(setid);
	inputcolor[teller]=color;
	console.log(inputcolor);

/*	if (colorchoise) {
		console.log(setid+" bestaat al");
		}*/
	//maximaal maar 48 velden plaatsen om de 12 pogingen te halen
	if (teller < 48) {
		fldset.setAttribute("id","invoer"+teller+"");
		id_row1.appendChild(fldset);
		fldset.setAttribute("style", "background-color:"+color+"");
	}

	//vergelijken met de kleurcode bij elk poging
	if (teller == 3) {
		if (input[0] == inputcolor[0]) {
			alert("good");
		}else if (input.indexOf(inputcolor[0])>-1) {
			alert("not the right place");
		}
		else {alert("not in sequence");}
	}
	else if (teller == 7){
		alert("dit was de tweede poging")
		/*checkorange();*/
	}
	else if (teller == 11){
		alert("dit was de derde poging")
	}
	else if (teller == 15){
		alert("dit was de vierde poging")
	}
	else if (teller == 19){
		alert("dit was de vijfde poging")
	}
	else if (teller == 23){
		alert("dit was de zesde poging")
	}
	else if (teller == 27){
		alert("dit was de zevende poging")
	}
	else if (teller == 31){
		alert("dit was de achtste poging")
	}
	else if (teller == 35){
		alert("dit was de negende poging")
	}
	else if (teller == 39){
		alert("dit was de tiende poging")
	}
	else if (teller == 43){
		alert("dit was de elfde poging")
	}
	else if (teller == 47){
		alert("dit was de twaalfde poging")
	}

	teller = teller +1; 
}

function checkorange() {
//in HMTML de kleuren rijen heeft elke kleur zijn eigen ID zodra je ze invoert, hiermee moet vergeleken worden.
//variabele van de kleuren

//1 vergelijken met p1

// if (input[0] == p1.style.backgroundColor) {
// 	console.log("orange");
// 	}else if (p1.style.backgroundColor != input[0]){
// 	console.log("false");
// 	}

// if (input[1] == p1.style.backgroundColor) {
// 	console.log("orange");
// 	}else if (p1.style.backgroundColor != input[1]){
// 	console.log("false");
// 	}
// if (input[2] == p1.style.backgroundColor) {
// 	console.log("orange");
// 	}else if (p1.style.backgroundColor != input[2]){
// 	console.log("false");
// 	}

// if (input[3] == p1.style.backgroundColor) {
// 	console.log("orange");
// 	}else if (p1.style.backgroundColor != input[3]){
// 	console.log("false");
// 	}
}
